<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $rol = $_POST['rol'];

    $stmt = $pdo->prepare("SELECT * FROM usuario WHERE email = ? AND tipo = ?");
    $stmt->execute([$email, $rol]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['contraseña'])) {
        echo "Bienvenido, " . $user['nombre'] . " (" . $user['tipo'] . ")";
    } else {
        echo "Credenciales incorrectas o usuario no encontrado.";
    }
}
?>
