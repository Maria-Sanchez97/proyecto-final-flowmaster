<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_cliente = 1; // ejemplo fijo
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("INSERT INTO pedido (id_cliente) VALUES (?)");
    $stmt->execute([$id_cliente]);
    $id_pedido = $pdo->lastInsertId();

    $productos = [
        1 => $_POST['producto_1'] ?? 0,
        2 => $_POST['producto_2'] ?? 0,
        3 => $_POST['producto_3'] ?? 0,
    ];

    foreach ($productos as $id_producto => $cantidad) {
        if ($cantidad > 0) {
            $stmt = $pdo->prepare("SELECT precio FROM producto WHERE id_producto = ?");
            $stmt->execute([$id_producto]);
            $precio_unitario = $stmt->fetchColumn();
            $stmt = $pdo->prepare("INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)");
            $stmt->execute([$id_pedido, $id_producto, $cantidad, $precio_unitario]);
        }
    }

    $pdo->commit();
    echo "Pedido registrado con éxito.";
}
?>
