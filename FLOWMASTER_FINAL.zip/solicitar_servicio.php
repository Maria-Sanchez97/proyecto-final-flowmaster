<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tipo = $_POST['tipo'];
    $descripcion = $_POST['descripcion'];
    $producto = $_POST['producto'];
    $id_cliente = 1; // ejemplo fijo

    $stmt = $pdo->prepare("INSERT INTO servicio (tipo, descripcion, id_cliente) VALUES (?, ?, ?)");
    $stmt->execute([$tipo, $descripcion, $id_cliente]);

    echo "Solicitud de servicio enviada correctamente.";
}
?>
